
Hi there! Thanks for downloading my font and for taking the time to read this file.

Important: It's Donation Ware*, so if you want to use it commercially,
please consider an appropriate donation via Paypal to 

paypal@anke-art.de

Or send me a sample of your creative work to:
Anke Arnold, Goethestr. 47, 73249 Wernau, Germany

Thank you! *Other ways of donating (Amazon or Etsy Wishlist) can be found at www.anke-art.de, just click on the "Thank You" link.

Have fun with my font!
Anke